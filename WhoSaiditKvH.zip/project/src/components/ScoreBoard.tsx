import React from 'react';

interface ScoreBoardProps {
  correct: number;
  incorrect: number;
}

const ScoreBoard: React.FC<ScoreBoardProps> = ({ correct, incorrect }) => {
  const total = correct + incorrect;
  const percentage = total > 0 ? Math.round((correct / total) * 100) : 0;
  
  return (
    <div className="flex gap-4 w-full max-w-md">
      <div className="bg-white rounded-lg shadow-md p-4 flex-1 text-center">
        <div className="text-green-600 font-bold text-2xl">{correct}</div>
        <div className="text-sm text-gray-600">Correct</div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 flex-1 text-center">
        <div className="text-xl font-bold text-2xl">{percentage}%</div>
        <div className="text-sm text-gray-600">Accuracy</div>
      </div>
      
      <div className="bg-white rounded-lg shadow-md p-4 flex-1 text-center">
        <div className="text-red-600 font-bold text-2xl">{incorrect}</div>
        <div className="text-sm text-gray-600">Incorrect</div>
      </div>
    </div>
  );
};

export default ScoreBoard;
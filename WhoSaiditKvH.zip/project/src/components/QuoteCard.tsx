import React from 'react';
import { Quote } from '../data/quotes';

interface QuoteCardProps {
  quote: Quote;
  onGuess: (guess: 'kanye' | 'hitler') => void;
  isAnswered: boolean;
  isCorrect: boolean | null;
}

const QuoteCard: React.FC<QuoteCardProps> = ({ quote, onGuess, isAnswered, isCorrect }) => {
  return (
    <div className="bg-white rounded-lg shadow-lg p-8 max-w-2xl w-full">
      <div className="mb-8">
        <blockquote className="text-2xl italic font-medium text-gray-800 text-center">
          "{quote.text}"
        </blockquote>
      </div>
      
      {!isAnswered ? (
        <div className="flex justify-center gap-8">
          <button
            onClick={() => onGuess('kanye')}
            className="flex flex-col items-center transition-transform hover:scale-105 focus:outline-none"
          >
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-transparent hover:border-gray-300 transition-all">
              <img 
                src="https://ichef.bbci.co.uk/ace/ws/640/cpsprodpb/0C47/production/_121134130_ye_getty.jpg.webp" 
                alt="Kanye West" 
                className="w-full h-full object-cover"
              />
            </div>
            <span className="mt-2 font-medium">Kanye West</span>
          </button>
          
          <button
            onClick={() => onGuess('hitler')}
            className="flex flex-col items-center transition-transform hover:scale-105 focus:outline-none"
          >
            <div className="w-32 h-32 rounded-full overflow-hidden border-4 border-transparent hover:border-gray-300 transition-all">
              <img 
                src="https://www.pulitzer.org/cms/sites/default/files/main_images/hitler_newspaper.jpg" 
                alt="Hitler" 
                className="w-full h-full object-cover"
              />
            </div>
            <span className="mt-2 font-medium">Hitler</span>
          </button>
        </div>
      ) : (
        <div className="text-center">
          <div className={`text-xl font-bold mb-4 ${isCorrect ? 'text-green-600' : 'text-red-600'}`}>
            {isCorrect ? 'Correct!' : 'Incorrect!'}
          </div>
          <div className="mb-4">
            This was said by <span className="font-bold">{quote.author === 'kanye' ? 'Kanye West' : 'Hitler'}</span>
          </div>
          <button
            onClick={() => onGuess(quote.author)}
            className="px-6 py-3 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
          >
            Next Quote
          </button>
        </div>
      )}
    </div>
  );
};

export default QuoteCard;
// Quotes data for the game
export interface Quote {
  text: string;
  author: 'kanye' | 'hitler';
}

export const quotes: Quote[] = [
  // Kanye West quotes
  {
    text: "I am the greatest artist that God has ever created.",
    author: "kanye"
  },
  {
    text: "I am a god.",
    author: "kanye"
  },
  {
    text: "My greatest pain in life is that I will never be able to see myself perform live.",
    author: "kanye"
  },
  {
    text: "I feel like I'm too busy writing history to read it.",
    author: "kanye"
  },
  {
    text: "I'm not going to be somebody who lets my success get in the way of my dreams.",
    author: "kanye"
  },
  {
    text: "I think I do myself a disservice by comparing myself to Steve Jobs and Walt Disney and human beings that we've seen before. It should be more like Willy Wonka...and welcome to my chocolate factory.",
    author: "kanye"
  },
  {
    text: "I will go down as the voice of this generation, of this decade, I will be the loudest voice.",
    author: "kanye"
  },
  {
    text: "I'm like a vessel, and God has chosen me to be the voice and the connector.",
    author: "kanye"
  },
  {
    text: "I am Warhol. I am the No. 1 most impactful artist of our generation. I am Shakespeare in the flesh.",
    author: "kanye"
  },
  {
    text: "For me, money is not my definition of success. Inspiring people is a definition of success.",
    author: "kanye"
  },
  {
    text: "People always tell you, 'Be humble. Be humble.' When was the last time someone told you to be amazing? Be great! Be awesome! Be awesome!",
    author: "kanye"
  },
  {
    text: "I'm a creative genius and there's no other way to word it.",
    author: "kanye"
  },
  {
    text: "I hate when I'm on a flight and I wake up with a water bottle next to me like oh great now I gotta be responsible for this water bottle.",
    author: "kanye"
  },
  {
    text: "Sometimes I push the door close button on people running towards the elevator. I just need my own elevator sometimes. My sanctuary.",
    author: "kanye"
  },
  {
    text: "I still think I am the greatest.",
    author: "kanye"
  },
  {
    text: "I'm going down as a legend, whether or not you like me or not. I am the new Jim Morrison. I am the new Kurt Cobain.",
    author: "kanye"
  },
  {
    text: "You can't look at a glass half full or empty if it's overflowing.",
    author: "kanye"
  },
  {
    text: "I would never want a book's autograph. I am a proud non-reader of books.",
    author: "kanye"
  },
  {
    text: "Everything I'm not made me everything I am.",
    author: "kanye"
  },
  {
    text: "I feel like me and Taylor might still have sex. Why? I made that bitch famous.",
    author: "kanye"
  },
  
  // Hitler quotes
  {
    text: "The strength of a nation derives from the integrity of the home.",
    author: "hitler"
  },
  {
    text: "If you tell a big enough lie and tell it frequently enough, it will be believed.",
    author: "hitler"
  },
  {
    text: "He alone, who owns the youth, gains the future.",
    author: "hitler"
  },
  {
    text: "Words build bridges into unexplored regions.",
    author: "hitler"
  },
  {
    text: "Great liars are also great magicians.",
    author: "hitler"
  },
  {
    text: "The victor will never be asked if he told the truth.",
    author: "hitler"
  },
  {
    text: "The very first essential for success is a perpetually constant and regular employment of violence.",
    author: "hitler"
  },
  {
    text: "Anyone who sees and paints a sky green and fields blue ought to be sterilized.",
    author: "hitler"
  },
  {
    text: "The art of reading and studying consists in remembering the essentials and forgetting what is not essential.",
    author: "hitler"
  },
  {
    text: "I use emotion for the many and reserve reason for the few.",
    author: "hitler"
  },
  {
    text: "All propaganda has to be popular and has to accommodate itself to the comprehension of the least intelligent of those whom it seeks to reach.",
    author: "hitler"
  },
  {
    text: "The great masses of the people will more easily fall victims to a big lie than to a small one.",
    author: "hitler"
  },
  {
    text: "Strength lies not in defense but in attack.",
    author: "hitler"
  },
  {
    text: "Those who want to live, let them fight, and those who do not want to fight in this world of eternal struggle do not deserve to live.",
    author: "hitler"
  },
  {
    text: "It is not truth that matters, but victory.",
    author: "hitler"
  },
  {
    text: "The leader of genius must have the ability to make different opponents appear as if they belonged to one category.",
    author: "hitler"
  },
  {
    text: "The doom of a nation can be averted only by a storm of flowing passion, but only those who are passionate themselves can arouse passion in others.",
    author: "hitler"
  },
  {
    text: "Success is the sole earthly judge of right and wrong.",
    author: "hitler"
  },
  {
    text: "The day of individual happiness has passed.",
    author: "hitler"
  },
  {
    text: "Universal education is the most corroding and disintegrating poison that liberalism has ever invented for its own destruction.",
    author: "hitler"
  }
];
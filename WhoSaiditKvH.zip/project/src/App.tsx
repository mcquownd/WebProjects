import React, { useState, useEffect } from 'react';
import { Quote, quotes } from './data/quotes';
import QuoteCard from './components/QuoteCard';
import ScoreBoard from './components/ScoreBoard';
import { Shuffle } from 'lucide-react';

function App() {
  const [gameQuotes, setGameQuotes] = useState<Quote[]>([]);
  const [currentQuoteIndex, setCurrentQuoteIndex] = useState(0);
  const [isAnswered, setIsAnswered] = useState(false);
  const [isCorrect, setIsCorrect] = useState<boolean | null>(null);
  const [score, setScore] = useState({ correct: 0, incorrect: 0 });

  const shuffleQuotes = () => {
    const shuffled = [...quotes].sort(() => Math.random() - 0.5);
    setGameQuotes(shuffled);
    setCurrentQuoteIndex(0);
    setIsAnswered(false);
    setIsCorrect(null);
  };

  // Initialize and shuffle quotes on component mount
  useEffect(() => {
    shuffleQuotes();
  }, []);

  const handleGuess = (guess: 'kanye' | 'hitler') => {
    if (isAnswered) {
      // If already answered, this is the "Next" button click
      moveToNextQuote();
      return;
    }

    const currentQuote = gameQuotes[currentQuoteIndex];
    const isGuessCorrect = guess === currentQuote.author;
    
    setIsAnswered(true);
    setIsCorrect(isGuessCorrect);
    
    if (isGuessCorrect) {
      setScore(prev => ({ ...prev, correct: prev.correct + 1 }));
    } else {
      setScore(prev => ({ ...prev, incorrect: prev.incorrect + 1 }));
    }
  };

  const moveToNextQuote = () => {
    setIsAnswered(false);
    setIsCorrect(null);
    
    // If we're at the end of our quotes, shuffle and start over
    if (currentQuoteIndex >= gameQuotes.length - 1) {
      shuffleQuotes();
    } else {
      setCurrentQuoteIndex(prev => prev + 1);
    }
  };

  const currentQuote = gameQuotes[currentQuoteIndex];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-100 to-gray-200 flex flex-col items-center justify-center p-4">
      <header className="mb-8 text-center">
        <h1 className="text-4xl font-bold text-gray-800 mb-2">Kanye or Hitler?</h1>
        <p className="text-gray-600 max-w-md mx-auto">
          Can you tell who said it? Test your knowledge by guessing whether each quote was said by Kanye West or Adolf Hitler.
        </p>
      </header>

      <div className="mb-8">
        <ScoreBoard correct={score.correct} incorrect={score.incorrect} />
      </div>

      {currentQuote && (
        <QuoteCard 
          quote={currentQuote} 
          onGuess={handleGuess} 
          isAnswered={isAnswered} 
          isCorrect={isCorrect} 
        />
      )}

      <button 
        onClick={shuffleQuotes}
        className="mt-8 flex items-center gap-2 text-gray-600 hover:text-gray-800 transition-colors"
      >
        <Shuffle size={16} />
        Shuffle Quotes
      </button>
    </div>
  );
}

export default App;